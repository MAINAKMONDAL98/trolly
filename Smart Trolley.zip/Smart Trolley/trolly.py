
from time import sleep
import sys
from mfrc522 import SimpleMFRC522
import I2C_LCD_driver
from time import *
from Adafruit_IO import*

reader = SimpleMFRC522()
mylcd = I2C_LCD_driver.lcd()
maik=Client('SurabhiShrivastava','aio_FSQw92iLOAmyk1bXMv8LV6idsi4P')
count=0
price=0
try:
    while True:
        print("Hold a tag near the reader")
        id, text = reader.read()
        mylcd.lcd_clear()
        print("ID: %s\nText: %s" % (id,text))
        if id==282178882007:
            num=input('Enter number:')
            if num=="3":
                price=price-10
                count=count-1;
            else:
                price=price+10
                count=count+1;
            #price=price+10
            mylcd.lcd_display_string("Oreo",1)
            mylcd.lcd_display_string(str(price),2,3)
            maik.send("product","Oreo")
            maik.send("price",price)
        elif id==40020738100:
            num=input('Enter number:')
            if num=="3":
                price=price-20
                count=count-1;
            else:
                price=price+20
                count=count+1;
            #price=price+20
            mylcd.lcd_display_string("Dairymilk",1)
            mylcd.lcd_display_string(str(price),2,3)
            maik.send("product","Dairymilk")
            maik.send("price",price)
        sleep(1)
        #mylcd.lcd_clear()
        #count=count+1;
        mylcd.lcd_display_string(str(count),2)
        sleep(5)
        #mylcd.lcd_clear()
        #maik.send("product",id)
        sleep(5)
except KeyboardInterrupt:
    GPIO.cleanup()
    raise
